import { 
  users, labourerProfiles, contractorProfiles,
  type User, type InsertUser, 
  type LabourerProfile, type InsertLabourerProfile, 
  type ContractorProfile, type InsertContractorProfile,
  type UserWithProfile
} from "@shared/schema";
import { db } from "./db";
import { eq, like, and, or } from "drizzle-orm";

export interface IStorage {
  // User & Auth
  getUser(id: number): Promise<User | undefined>;
  getUserByMobile(mobile: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Profiles
  createLabourerProfile(profile: InsertLabourerProfile): Promise<LabourerProfile>;
  getLabourerProfile(userId: number): Promise<LabourerProfile | undefined>;
  updateLabourerProfile(userId: number, profile: Partial<InsertLabourerProfile>): Promise<LabourerProfile>;
  
  createContractorProfile(profile: InsertContractorProfile): Promise<ContractorProfile>;
  getContractorProfile(userId: number): Promise<ContractorProfile | undefined>;
  
  // Search
  searchLabourers(filters: { city?: string; skill?: string; search?: string }): Promise<UserWithProfile[]>;
  
  // Full User Fetch
  getUserWithProfile(id: number): Promise<UserWithProfile | undefined>;
  
  // Admin
  listUsers(role?: string): Promise<UserWithProfile[]>;
  blockUser(id: number, blocked: boolean): Promise<void>;
  verifyLabourer(userId: number, verified: boolean): Promise<void>;
  
  // Contractor
  addLabourerToContractor(contractorId: number, labourerId: number): Promise<void>;
  removeLabourerFromContractor(contractorId: number, labourerId: number): Promise<void>;
}

export class DatabaseStorage implements IStorage {
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async getUserByMobile(mobile: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.mobile, mobile));
    return user;
  }

  async createUser(user: InsertUser): Promise<User> {
    const [newUser] = await db.insert(users).values(user).returning();
    return newUser;
  }

  async createLabourerProfile(profile: InsertLabourerProfile): Promise<LabourerProfile> {
    const [newProfile] = await db.insert(labourerProfiles).values(profile).returning();
    return newProfile;
  }

  async getLabourerProfile(userId: number): Promise<LabourerProfile | undefined> {
    const [profile] = await db.select().from(labourerProfiles).where(eq(labourerProfiles.userId, userId));
    return profile;
  }

  async updateLabourerProfile(userId: number, profile: Partial<InsertLabourerProfile>): Promise<LabourerProfile> {
      const [updated] = await db.update(labourerProfiles)
        .set(profile)
        .where(eq(labourerProfiles.userId, userId))
        .returning();
      return updated;
  }

  async createContractorProfile(profile: InsertContractorProfile): Promise<ContractorProfile> {
    const [newProfile] = await db.insert(contractorProfiles).values(profile).returning();
    return newProfile;
  }

  async getContractorProfile(userId: number): Promise<ContractorProfile | undefined> {
    const [profile] = await db.select().from(contractorProfiles).where(eq(contractorProfiles.userId, userId));
    return profile;
  }

  async getUserWithProfile(id: number): Promise<UserWithProfile | undefined> {
    const user = await this.getUser(id);
    if (!user) return undefined;

    const labourerProfile = await this.getLabourerProfile(user.id);
    const contractorProfile = await this.getContractorProfile(user.id);

    return { ...user, labourerProfile, contractorProfile };
  }

  async searchLabourers(filters: { city?: string; skill?: string; search?: string }): Promise<UserWithProfile[]> {
    // Start with a query on users
    let query = db.select({
      user: users,
      labourer: labourerProfiles,
    })
    .from(users)
    .innerJoin(labourerProfiles, eq(users.id, labourerProfiles.userId));

    const conditions = [];
    conditions.push(eq(users.role, "labourer"));
    conditions.push(eq(users.isBlocked, false)); // Exclude blocked users

    if (filters.city) {
      conditions.push(like(users.city, `%${filters.city}%`));
    }
    if (filters.skill) {
      conditions.push(eq(labourerProfiles.skillCategory, filters.skill as any));
    }
    if (filters.search) {
      conditions.push(or(
        like(users.name, `%${filters.search}%`),
        like(users.city, `%${filters.search}%`)
      ));
    }

    const results = await query.where(and(...conditions));
    
    return results.map(r => ({
      ...r.user,
      labourerProfile: r.labourer,
    }));
  }

  async listUsers(role?: string): Promise<UserWithProfile[]> {
    const allUsers = await db.select().from(users);
    let filtered = allUsers;
    if (role) {
      filtered = filtered.filter(u => u.role === role);
    }
    
    const withProfiles = await Promise.all(
      filtered.map(u => this.getUserWithProfile(u.id))
    );
    
    return withProfiles.filter(Boolean) as UserWithProfile[];
  }

  async blockUser(id: number, blocked: boolean): Promise<void> {
    await db.update(users).set({ isBlocked: blocked }).where(eq(users.id, id));
  }

  async verifyLabourer(userId: number, verified: boolean): Promise<void> {
    await db.update(labourerProfiles).set({ isVerified: verified }).where(eq(labourerProfiles.userId, userId));
  }

  async addLabourerToContractor(contractorId: number, labourerId: number): Promise<void> {
    const [labProfile] = await db.select().from(labourerProfiles).where(eq(labourerProfiles.userId, labourerId));
    if (labProfile) {
      await db.update(labourerProfiles).set({ contractorId }).where(eq(labourerProfiles.id, labProfile.id));
    }
  }

  async removeLabourerFromContractor(contractorId: number, labourerId: number): Promise<void> {
    const [labProfile] = await db.select().from(labourerProfiles).where(eq(labourerProfiles.userId, labourerId));
    if (labProfile && labProfile.contractorId === contractorId) {
      await db.update(labourerProfiles).set({ contractorId: null }).where(eq(labourerProfiles.id, labProfile.id));
    }
  }
}

export const storage = new DatabaseStorage();
