import type { Express } from "express";
import type { Server } from "http";
import { storage } from "./storage";
import { api } from "@shared/routes";
import { z } from "zod";
import { insertUserSchema } from "@shared/schema";

// Mock OTP Store (In-memory for MVP)
const otpStore = new Map<string, string>();

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {

  // Auth: Send OTP
  app.post(api.auth.sendOtp.path, async (req, res) => {
    const { mobile } = req.body;
    // Mock OTP generation
    const otp = "1234"; 
    otpStore.set(mobile, otp);
    console.log(`[Mock OTP] Mobile: ${mobile}, OTP: ${otp}`);
    res.json({ message: "OTP sent successfully (Use 1234)" });
  });

  // Auth: Verify OTP
  app.post(api.auth.verifyOtp.path, async (req, res) => {
    const { mobile, code } = req.body;
    
    if (code !== "1234" && otpStore.get(mobile) !== code) {
      return res.status(400).json({ message: "Invalid OTP" });
    }

    // Check if user exists
    let user = await storage.getUserByMobile(mobile);
    
    if (user) {
      // Login
      const fullUser = await storage.getUserWithProfile(user.id);
      return res.json({ token: "mock-token-123", user: fullUser });
    } else {
      // User needs to register
      // For MVP, we'll return a specific status or message indicating registration needed
      // But the API contract expects 200 with user, or we can handle "not found" logic
      // Actually, if user doesn't exist, we can't return a user object yet.
      // Let's modify the flow: 
      // If user exists -> 200 OK + User
      // If user doesn't exist -> 200 OK + user: null (Client triggers registration)
      return res.json({ token: "temp-token", user: null });
    }
  });

  // Auth: Register
  app.post(api.auth.register.path, async (req, res) => {
    try {
      const input = api.auth.register.input.parse(req.body);
      
      // 1. Create User
      const user = await storage.createUser({
        mobile: input.mobile,
        name: input.name,
        city: input.city,
        role: input.role
      });

      // 2. Create Profile based on role
      if (input.role === "labourer" && input.skillCategory) {
        await storage.createLabourerProfile({
          userId: user.id,
          skillCategory: input.skillCategory,
          experienceYears: input.experienceYears || 0,
          dailyRate: input.dailyRate || 0,
          isAvailable: true,
          isVerified: false
        });
      } else if (input.role === "contractor") {
        await storage.createContractorProfile({
          userId: user.id,
          organizationName: input.organizationName,
          isVerified: false
        });
      }

      const fullUser = await storage.getUserWithProfile(user.id);
      res.status(201).json({ token: "mock-token-123", user: fullUser });

    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({
          message: err.errors[0].message,
          field: err.errors[0].path.join('.'),
        });
      }
      throw err;
    }
  });

  // Auth: Me
  app.get(api.auth.me.path, async (req, res) => {
      // Mock "Me" - usually would parse token. 
      // For MVP without real JWT middleware, we might need to pass ID in header or query
      // or just assume this endpoint is used to refresh state if we had a cookie.
      // Since we don't have middleware yet, let's just skip this or implement basic ID check
      // For simplicity, we'll rely on client state for now, or just return 401
      res.status(401).json({ message: "Not authenticated" });
  });

  // Labourers: List
  app.get(api.labourers.list.path, async (req, res) => {
    const { city, skill, search } = req.query as any;
    const labourers = await storage.searchLabourers({ city, skill, search });
    res.json(labourers);
  });

  // Labourers: Get
  app.get(api.labourers.get.path, async (req, res) => {
    const id = parseInt(req.params.id);
    const labourer = await storage.getUserWithProfile(id);
    if (!labourer || labourer.role !== "labourer") {
      return res.status(404).json({ message: "Labourer not found" });
    }
    res.json(labourer);
  });

   // Labourers: Update
   app.put(api.labourers.update.path, async (req, res) => {
       const id = parseInt(req.params.id);
       try {
           const input = api.labourers.update.input.parse(req.body);
           const updated = await storage.updateLabourerProfile(id, input);
           res.json(updated);
       } catch (err) {
            res.status(400).json({ message: "Invalid input" });
       }
   });

  // Contractors: Add Labourer
  app.post(api.contractors.addLabourer.path, async (req, res) => {
    const contractorId = parseInt(req.params.id);
    const { labourerId } = req.body;
    try {
      await storage.addLabourerToContractor(contractorId, labourerId);
      res.json({ message: "Labourer added" });
    } catch (err) {
      res.status(404).json({ message: "Not found" });
    }
  });

  // Contractors: Remove Labourer
  app.delete(api.contractors.removeLabourer.path, async (req, res) => {
    const contractorId = parseInt(req.params.id);
    const labourerId = parseInt(req.params.labourerId);
    try {
      await storage.removeLabourerFromContractor(contractorId, labourerId);
      res.json({ message: "Labourer removed" });
    } catch (err) {
      res.status(404).json({ message: "Not found" });
    }
  });

  // Admin: List Users
  app.get(api.admin.listUsers.path, async (req, res) => {
    const { role, blocked } = req.query as any;
    try {
      const users = await storage.listUsers(role);
      res.json(users);
    } catch (err) {
      res.status(401).json({ message: "Unauthorized" });
    }
  });

  // Admin: Verify User
  app.patch(api.admin.verifyUser.path, async (req, res) => {
    const userId = parseInt(req.params.id);
    const { verified } = req.body;
    try {
      await storage.verifyLabourer(userId, verified);
      res.json({ message: "User verification updated" });
    } catch (err) {
      res.status(404).json({ message: "User not found" });
    }
  });

  // Admin: Block User
  app.patch(api.admin.blockUser.path, async (req, res) => {
    const userId = parseInt(req.params.id);
    const { blocked } = req.body;
    try {
      await storage.blockUser(userId, blocked);
      res.json({ message: "User status updated" });
    } catch (err) {
      res.status(404).json({ message: "User not found" });
    }
  });

  return httpServer;
}

// Seed Data
async function seedDatabase() {
    // Check if data exists
    const sampleUser = await storage.getUserByMobile("9876543210");
    if (!sampleUser) {
        console.log("Seeding Database...");
        
        // 1. Create Labourer: Rajesh (Mason)
        const rajesh = await storage.createUser({
            mobile: "9876543210",
            name: "Rajesh Kumar",
            city: "Delhi",
            role: "labourer"
        });
        await storage.createLabourerProfile({
            userId: rajesh.id,
            skillCategory: "Mason",
            experienceYears: 5,
            dailyRate: 800,
            isAvailable: true,
            bio: "Expert in brick laying and plastering."
        });

        // 2. Create Labourer: Suresh (Electrician)
        const suresh = await storage.createUser({
            mobile: "9988776655",
            name: "Suresh Singh",
            city: "Mumbai",
            role: "labourer"
        });
        await storage.createLabourerProfile({
            userId: suresh.id,
            skillCategory: "Electrician",
            experienceYears: 3,
            dailyRate: 600,
            isAvailable: true,
            bio: "House wiring and appliance repair."
        });
        
         // 3. Create Contractor: BuildWell
        const contractor = await storage.createUser({
            mobile: "1122334455",
            name: "Amit Builders",
            city: "Delhi",
            role: "contractor"
        });
        await storage.createContractorProfile({
            userId: contractor.id,
            organizationName: "BuildWell Constructions",
            isVerified: true
        });

        console.log("Seeding Completed.");
    }
}

// Helper to run seed
setTimeout(seedDatabase, 2000);
