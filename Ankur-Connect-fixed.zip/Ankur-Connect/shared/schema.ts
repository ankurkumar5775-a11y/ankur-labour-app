import { pgTable, text, serial, integer, boolean, timestamp, numeric } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";
import { relations } from "drizzle-orm";

export const USER_ROLES = ["customer", "labourer", "contractor", "admin"] as const;
export const SKILL_CATEGORIES = [
  "Mason", "Electrician", "Plumber", "Painter", "Carpenter", "Helper", "Daily Wage Worker", "Other"
] as const;

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  mobile: text("mobile").notNull().unique(),
  name: text("name").notNull(),
  city: text("city").notNull(),
  role: text("role", { enum: USER_ROLES }).notNull(),
  isBlocked: boolean("is_blocked").default(false),
  createdAt: timestamp("created_at").defaultNow(),
});

export const labourerProfiles = pgTable("labourer_profiles", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  skillCategory: text("skill_category", { enum: SKILL_CATEGORIES }).notNull(),
  experienceYears: integer("experience_years").default(0),
  dailyRate: integer("daily_rate").default(0),
  isAvailable: boolean("is_available").default(true),
  bio: text("bio"),
  contractorId: integer("contractor_id"), // Optional: linked to a contractor
  isVerified: boolean("is_verified").default(false),
});

export const contractorProfiles = pgTable("contractor_profiles", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  organizationName: text("organization_name"),
  isVerified: boolean("is_verified").default(false),
});

// Relations
export const usersRelations = relations(users, ({ one }) => ({
  labourerProfile: one(labourerProfiles, {
    fields: [users.id],
    references: [labourerProfiles.userId],
  }),
  contractorProfile: one(contractorProfiles, {
    fields: [users.id],
    references: [contractorProfiles.userId],
  }),
}));

export const labourerProfilesRelations = relations(labourerProfiles, ({ one }) => ({
  user: one(users, {
    fields: [labourerProfiles.userId],
    references: [users.id],
  }),
}));

export const contractorProfilesRelations = relations(contractorProfiles, ({ one }) => ({
  user: one(users, {
    fields: [contractorProfiles.userId],
    references: [users.id],
  }),
}));

// Schemas
export const insertUserSchema = createInsertSchema(users).omit({ id: true, createdAt: true });
export const insertLabourerProfileSchema = createInsertSchema(labourerProfiles).omit({ id: true });
export const insertContractorProfileSchema = createInsertSchema(contractorProfiles).omit({ id: true });

// Types
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;
export type LabourerProfile = typeof labourerProfiles.$inferSelect;
export type InsertLabourerProfile = z.infer<typeof insertLabourerProfileSchema>;
export type ContractorProfile = typeof contractorProfiles.$inferSelect;
export type InsertContractorProfile = z.infer<typeof insertContractorProfileSchema>;

// API Request Types
export type LoginRequest = { mobile: string };
export type VerifyOtpRequest = { mobile: string; code: string };
export type RegisterRequest = InsertUser & {
  // Optional profile fields depending on role
  skillCategory?: typeof SKILL_CATEGORIES[number];
  experienceYears?: number;
  dailyRate?: number;
  organizationName?: string;
};

// Response Types including joined data
export type UserWithProfile = User & {
  labourerProfile?: LabourerProfile | null;
  contractorProfile?: ContractorProfile | null;
};
