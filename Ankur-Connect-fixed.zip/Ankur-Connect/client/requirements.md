## Packages
framer-motion | Smooth page transitions and micro-interactions
lucide-react | Iconography for skills and navigation

## Notes
Mobile-first design approach
Using earthy orange (#E65100) as primary color for construction theme
Dual language support implemented via UI labels (English / Hindi)
