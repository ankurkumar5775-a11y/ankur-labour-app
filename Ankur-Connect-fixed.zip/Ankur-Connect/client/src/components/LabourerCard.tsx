import { UserWithProfile } from "@/hooks/use-auth";
import { Phone, MapPin, BadgeCheck, MessageCircle } from "lucide-react";
import { motion } from "framer-motion";
import { Tooltip, TooltipContent, TooltipTrigger } from "@/components/ui/tooltip";

interface LabourerCardProps {
  labourer: UserWithProfile;
  onCall: (mobile: string) => void;
}

export function LabourerCard({ labourer, onCall }: LabourerCardProps) {
  const profile = labourer.labourerProfile;
  if (!profile) return null;

  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="bg-card rounded-2xl p-5 border border-border/50 shadow-sm hover:shadow-lg transition-all relative overflow-hidden group"
    >
      {/* Availability Indicator */}
      <div className={`absolute top-4 right-4 px-3 py-1.5 rounded-full text-xs font-bold flex items-center gap-1.5 ${profile.isAvailable ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'}`}>
        <div className={`w-2 h-2 rounded-full ${profile.isAvailable ? 'bg-green-500' : 'bg-red-500'}`} />
        {profile.isAvailable ? 'Available' : 'Busy'}
      </div>

      <div className="flex gap-4">
        {/* Avatar Placeholder - Initials */}
        <div className="w-16 h-16 rounded-xl bg-gradient-to-br from-primary/20 to-primary/5 flex items-center justify-center text-primary font-bold text-2xl shrink-0">
          {labourer.name.charAt(0).toUpperCase()}
        </div>

        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2">
            <h3 className="text-lg font-bold text-foreground truncate">{labourer.name}</h3>
            {profile.isVerified && (
              <Tooltip>
                <TooltipTrigger asChild>
                  <div className="cursor-help">
                    <BadgeCheck className="w-5 h-5 text-blue-500 fill-blue-500/20 shrink-0" />
                  </div>
                </TooltipTrigger>
                <TooltipContent side="right" className="text-xs">
                  Verified by ANKUR team
                </TooltipContent>
              </Tooltip>
            )}
          </div>
          
          <p className="text-primary font-semibold text-sm">{profile.skillCategory}</p>
          
          <div className="flex items-center gap-1 text-xs text-muted-foreground mt-1">
            <MapPin className="w-3 h-3" />
            {labourer.city}
          </div>

          {profile.contractorId && (
            <div className="mt-2 inline-block bg-amber-50 text-amber-700 text-xs font-semibold px-2.5 py-1 rounded-full">
              Managed by Contractor
            </div>
          )}
        </div>
      </div>

      <div className="mt-4 grid grid-cols-2 gap-3 text-xs">
        <div className="bg-secondary/50 p-2.5 rounded-lg flex flex-col items-center justify-center text-center">
          <span className="text-muted-foreground text-xs">Experience</span>
          <span className="font-bold text-sm mt-0.5">{profile.experienceYears} Yrs</span>
        </div>
        <div className="bg-secondary/50 p-2.5 rounded-lg flex flex-col items-center justify-center text-center">
          <span className="text-muted-foreground text-xs">Daily Rate</span>
          <span className="font-bold text-sm mt-0.5">₹{profile.dailyRate}</span>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-2.5 mt-5">
        <button
          onClick={() => onCall(labourer.mobile)}
          className="bg-primary text-white font-bold py-4 rounded-xl flex items-center justify-center gap-2 shadow-lg shadow-primary/30 hover:shadow-xl hover:shadow-primary/40 hover:-translate-y-0.5 active:scale-[0.97] transition-all text-sm"
          data-testid="button-call-now"
        >
          <Phone className="w-5 h-5" />
          Call Now
        </button>
        <button
          onClick={() => window.open(`https://wa.me/91${labourer.mobile}`)}
          className="bg-green-500 text-white font-bold py-4 rounded-xl flex items-center justify-center gap-2 shadow-lg shadow-green-500/30 hover:shadow-xl hover:shadow-green-500/40 hover:-translate-y-0.5 active:scale-[0.97] transition-all text-sm"
          data-testid="button-whatsapp"
        >
          <MessageCircle className="w-5 h-5" />
          WhatsApp
        </button>
      </div>
    </motion.div>
  );
}
