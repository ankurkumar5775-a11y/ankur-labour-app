import { Hammer, Zap, Droplets, PaintRoller, Ruler, Shovel, HardHat, MoreHorizontal } from "lucide-react";
import { cn } from "@/lib/utils";

interface SkillFilterProps {
  selectedSkill: string | null;
  onSelectSkill: (skill: string | null) => void;
}

const skills = [
  { id: "Mason", label: "Mason", hi: "राजमिस्त्री", icon: Hammer },
  { id: "Electrician", label: "Electrician", hi: "बिजली मिस्त्री", icon: Zap },
  { id: "Plumber", label: "Plumber", hi: "नलसाज", icon: Droplets },
  { id: "Painter", label: "Painter", hi: "पेंटर", icon: PaintRoller },
  { id: "Carpenter", label: "Carpenter", hi: "बढ़ई", icon: Ruler },
  { id: "Helper", label: "Helper", hi: "मजदूर", icon: Shovel },
  { id: "Daily Wage Worker", label: "Labor", hi: "दिहाड़ी", icon: HardHat },
  { id: "Other", label: "Other", hi: "अन्य", icon: MoreHorizontal },
];

export function SkillFilter({ selectedSkill, onSelectSkill }: SkillFilterProps) {
  return (
    <div className="w-full overflow-x-auto pb-4 px-4 -mx-4 hide-scrollbar">
      <div className="flex space-x-3 w-max">
        <button
          onClick={() => onSelectSkill(null)}
          className={cn(
            "flex flex-col items-center justify-center min-w-[80px] h-[80px] rounded-2xl border-2 transition-all duration-200",
            selectedSkill === null 
              ? "border-primary bg-primary/5 text-primary" 
              : "border-border bg-white text-muted-foreground hover:border-primary/50"
          )}
        >
          <span className="font-bold text-sm">All</span>
          <span className="text-xs opacity-70">सभी</span>
        </button>

        {skills.map((skill) => (
          <button
            key={skill.id}
            onClick={() => onSelectSkill(skill.id)}
            className={cn(
              "flex flex-col items-center justify-center min-w-[80px] h-[80px] rounded-2xl border-2 transition-all duration-200 gap-1",
              selectedSkill === skill.id 
                ? "border-primary bg-primary/5 text-primary" 
                : "border-border bg-white text-muted-foreground hover:border-primary/50"
            )}
          >
            <skill.icon className="w-6 h-6" />
            <div className="flex flex-col leading-none">
              <span className="text-[10px] font-bold">{skill.label}</span>
              <span className="text-[9px] opacity-70">{skill.hi}</span>
            </div>
          </button>
        ))}
      </div>
    </div>
  );
}
