import { Switch, Route, useLocation } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { BottomNav } from "@/components/BottomNav";
import { useAuth } from "@/hooks/use-auth";
import { LanguageProvider } from "@/contexts/LanguageContext";
import { Loader2 } from "lucide-react";

// Pages
import AuthPage from "@/pages/Auth";
import RegisterPage from "@/pages/Register";
import RoleSelect from "@/pages/RoleSelect";
import Admin from "@/pages/Admin";
import Home from "@/pages/Home";
import Profile from "@/pages/Profile";
import Connect from "@/pages/Connect";
import Splash from "@/pages/Splash";
import NotFound from "@/pages/not-found";

function ProtectedRoute({ component: Component }: { component: React.ComponentType }) {
  const { user, isLoading } = useAuth();
  const [, setLocation] = useLocation();

  if (isLoading) {
    return (
      <div className="h-screen flex items-center justify-center bg-background">
        <Loader2 className="w-10 h-10 text-primary animate-spin" />
      </div>
    );
  }

  if (!user) {
    // Ideally redirect to auth, but component might render briefly
    setTimeout(() => setLocation("/auth"), 0);
    return null;
  }

  return <Component />;
}

function Router() {
  const { user, isLoading } = useAuth();

  // If loading auth state, show a minimal loader or nothing to prevent flicker
  if (isLoading) {
    return <div className="min-h-screen bg-background" />;
  }

  return (
    <>
      <Switch>
        <Route path="/splash" component={Splash} />
        <Route path="/auth" component={AuthPage} />
        <Route path="/register" component={RegisterPage} />
        <Route path="/role-select" component={RoleSelect} />
        <Route path="/admin" component={Admin} />
        
        {/* Protected Routes */}
        <Route path="/">
          {user ? <Home /> : <AuthPage />}
        </Route>
        
        <Route path="/profile">
           {user ? <Profile /> : <AuthPage />}
        </Route>
        
        <Route path="/connect">
           {user ? <Connect /> : <AuthPage />}
        </Route>

        <Route component={NotFound} />
      </Switch>
      
      {/* Show Bottom Nav only if user is logged in */}
      {user && <BottomNav />}
    </>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <LanguageProvider>
        <Toaster />
        <Router />
      </LanguageProvider>
    </QueryClientProvider>
  );
}

export default App;
