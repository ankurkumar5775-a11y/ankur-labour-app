import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { api, type LoginRequest, type VerifyOtpRequest, type RegisterRequest } from "@shared/routes";
import { useToast } from "@/hooks/use-toast";

// Re-export type for ease of use
export type { UserWithProfile } from "@shared/schema";

export function useAuth() {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  const { data: user, isLoading } = useQuery({
    queryKey: [api.auth.me.path],
    queryFn: async () => {
      const res = await fetch(api.auth.me.path, { credentials: "include" });
      if (res.status === 401) return null;
      if (!res.ok) throw new Error("Failed to fetch user");
      return api.auth.me.responses[200].parse(await res.json());
    },
    retry: false,
  });

  const sendOtpMutation = useMutation({
    mutationFn: async (data: LoginRequest) => {
      const res = await fetch(api.auth.sendOtp.path, {
        method: api.auth.sendOtp.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });
      if (!res.ok) {
        const error = await res.json();
        throw new Error(error.message || "Failed to send OTP");
      }
      return api.auth.sendOtp.responses[200].parse(await res.json());
    },
    onSuccess: () => {
      toast({
        title: "OTP Sent / ओटीपी भेजा गया",
        description: "Please check your messages (Mock: 1234)",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Error / त्रुटि",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const verifyOtpMutation = useMutation({
    mutationFn: async (data: VerifyOtpRequest) => {
      const res = await fetch(api.auth.verifyOtp.path, {
        method: api.auth.verifyOtp.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
        credentials: "include",
      });
      if (!res.ok) {
        const error = await res.json();
        throw new Error(error.message || "Invalid OTP");
      }
      return api.auth.verifyOtp.responses[200].parse(await res.json());
    },
    onSuccess: (data) => {
      queryClient.setQueryData([api.auth.me.path], data.user);
      toast({
        title: "Welcome / स्वागत है",
        description: "Successfully logged in",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Error / त्रुटि",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const registerMutation = useMutation({
    mutationFn: async (data: RegisterRequest) => {
      // Coerce numbers properly before sending
      const payload = {
        ...data,
        experienceYears: data.experienceYears ? Number(data.experienceYears) : undefined,
        dailyRate: data.dailyRate ? Number(data.dailyRate) : undefined,
      };

      const res = await fetch(api.auth.register.path, {
        method: api.auth.register.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
        credentials: "include",
      });
      
      if (!res.ok) {
        const error = await res.json();
        throw new Error(error.message || "Registration failed");
      }
      return api.auth.register.responses[201].parse(await res.json());
    },
    onSuccess: (data) => {
      queryClient.setQueryData([api.auth.me.path], data.user);
      toast({
        title: "Registered / पंजीकृत",
        description: "Your profile has been created",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Error / त्रुटि",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const logoutMutation = useMutation({
    mutationFn: async () => {
      // For cookie auth, we just need to hit an endpoint or clear client state
      // Assuming server clears cookie on a logout endpoint if it existed
      // Since we don't have a logout endpoint in schema, we'll just clear client state
      queryClient.setQueryData([api.auth.me.path], null);
    },
    onSuccess: () => {
       window.location.reload(); // Hard refresh to clear any cached data
    }
  });

  const selectRole = (role: 'customer' | 'labourer' | 'contractor') => {
    // Update user role in cached data
    const currentUser = queryClient.getQueryData([api.auth.me.path]) as any;
    if (currentUser) {
      queryClient.setQueryData([api.auth.me.path], {
        ...currentUser,
        role
      });
    }
  };

  return {
    user,
    isLoading,
    sendOtp: sendOtpMutation.mutateAsync,
    isSendingOtp: sendOtpMutation.isPending,
    verifyOtp: verifyOtpMutation.mutateAsync,
    isVerifyingOtp: verifyOtpMutation.isPending,
    register: registerMutation.mutateAsync,
    isRegistering: registerMutation.isPending,
    logout: logoutMutation.mutate,
    selectRole,
  };
}
