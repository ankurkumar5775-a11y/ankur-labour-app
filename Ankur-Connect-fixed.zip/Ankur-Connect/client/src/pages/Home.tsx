import { useState } from "react";
import { useLabourers } from "@/hooks/use-labourers";
import { LabourerCard } from "@/components/LabourerCard";
import { SkillFilter } from "@/components/SkillFilter";
import { Search, Loader2, MapPin } from "lucide-react";
import { useAuth } from "@/hooks/use-auth";
import { Link } from "wouter";

export default function Home() {
  const [skill, setSkill] = useState<string | null>(null);
  const [city, setCity] = useState("");
  const [search, setSearch] = useState("");

  const { data: labourers, isLoading } = useLabourers({ 
    skill: skill || undefined, 
    city: city || undefined,
    search: search || undefined
  });

  const { user } = useAuth();

  const handleCall = (mobile: string) => {
    window.location.href = `tel:${mobile}`;
  };

  return (
    <div className="min-h-screen bg-background pb-24">
      {/* Header */}
      <header className="sticky top-0 z-40 bg-background/80 backdrop-blur-md border-b border-border p-4">
        <div className="flex justify-between items-center mb-4 max-w-2xl mx-auto">
          <div>
            <h1 className="text-2xl font-bold font-display text-primary">ANKUR</h1>
            {user && (
              <p className="text-xs text-muted-foreground mt-0.5">
                {user.name.split(' ')[0]} • <span className="capitalize font-semibold text-foreground">{user.role}</span>
              </p>
            )}
          </div>
          {user?.city && (
             <div className="flex items-center gap-1.5 text-xs bg-secondary px-3 py-1.5 rounded-full text-secondary-foreground font-semibold">
               <MapPin className="w-3 h-3" />
               {user.city}
             </div>
          )}
        </div>

        <div className="relative max-w-2xl mx-auto">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-muted-foreground w-4 h-4" />
          <input 
            type="text" 
            placeholder="Search workers by name or city..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full pl-10 pr-4 py-3 bg-white border border-border rounded-xl shadow-sm focus:outline-none focus:ring-2 focus:ring-primary/20 transition-all"
          />
        </div>
      </header>

      <main className="p-4 max-w-2xl mx-auto space-y-6">
        {/* Categories */}
        <section>
          <div className="flex justify-between items-baseline mb-3 px-1">
            <h2 className="font-bold text-lg">Categories / श्रेणियाँ</h2>
            <button onClick={() => setSkill(null)} className="text-xs text-primary font-semibold">View All</button>
          </div>
          <SkillFilter selectedSkill={skill} onSelectSkill={setSkill} />
        </section>

        {/* Results */}
        <section className="space-y-4">
          <h2 className="font-bold text-lg px-1">
            {skill ? `${skill}s Near You` : "Available Workers / उपलब्ध कर्मचारी"}
          </h2>

          {isLoading ? (
            <div className="flex flex-col items-center justify-center py-12">
              <Loader2 className="w-8 h-8 text-primary animate-spin mb-2" />
              <p className="text-muted-foreground text-sm">Finding workers...</p>
            </div>
          ) : labourers && labourers.length > 0 ? (
            <div className="grid gap-4 md:grid-cols-2">
              {labourers.map((worker) => (
                <LabourerCard key={worker.id} labourer={worker} onCall={handleCall} />
              ))}
            </div>
          ) : (
            <div className="text-center py-12 bg-white rounded-2xl border border-dashed border-border">
              <div className="w-16 h-16 bg-secondary rounded-full flex items-center justify-center mx-auto mb-4 text-3xl">👷</div>
              <h3 className="font-bold text-lg">No workers found</h3>
              <p className="text-muted-foreground">Try changing the category or search location.</p>
              <button onClick={() => { setSkill(null); setSearch(''); }} className="mt-4 text-primary font-semibold hover:underline">Clear Filters</button>
            </div>
          )}
        </section>
      </main>
    </div>
  );
}
