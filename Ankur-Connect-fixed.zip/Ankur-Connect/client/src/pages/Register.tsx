import { useState } from "react";
import { useAuth } from "@/hooks/use-auth";
import { useLocation, useSearch } from "wouter";
import { Loader2, Briefcase, User, HardHat, Building2, Check } from "lucide-react";
import { motion } from "framer-motion";
import { cn } from "@/lib/utils";
import { SKILL_CATEGORIES } from "@shared/schema";

export default function RegisterPage() {
  const searchStr = useSearch();
  const params = new URLSearchParams(searchStr);
  const mobile = params.get("mobile") || "";
  
  const [step, setStep] = useState<1 | 2>(1);
  const [formData, setFormData] = useState({
    name: "",
    city: "",
    role: "customer" as "customer" | "labourer" | "contractor",
    skillCategory: SKILL_CATEGORIES[0],
    experienceYears: "",
    dailyRate: "",
    organizationName: "",
  });

  const { register, isRegistering } = useAuth();
  const [, setLocation] = useLocation();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await register({
        mobile,
        ...formData,
        experienceYears: Number(formData.experienceYears),
        dailyRate: Number(formData.dailyRate),
      });
      setLocation("/");
    } catch (err) {
      // Handled in hook
    }
  };

  return (
    <div className="min-h-screen bg-background p-6 pb-24">
      <div className="max-w-2xl mx-auto space-y-8">
        <header>
          <h1 className="text-3xl font-bold text-primary font-display">Create Profile</h1>
          <p className="text-muted-foreground">प्रोफ़ाइल बनाएं</p>
        </header>

        <form onSubmit={handleSubmit} className="space-y-8">
          {/* Step 1: Role Selection */}
          <div className="space-y-4">
            <h2 className="text-lg font-semibold flex items-center gap-2">
              <span className="w-6 h-6 rounded-full bg-primary/10 text-primary flex items-center justify-center text-xs">1</span>
              Who are you? / आप कौन हैं?
            </h2>
            
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              {[
                { id: "customer", label: "Customer", sub: "ग्राहक", icon: User },
                { id: "labourer", label: "Worker", sub: "मजदूर", icon: HardHat },
                { id: "contractor", label: "Contractor", sub: "ठेकेदार", icon: Building2 },
              ].map((role) => (
                <button
                  key={role.id}
                  type="button"
                  onClick={() => setFormData(prev => ({ ...prev, role: role.id as any }))}
                  className={cn(
                    "p-4 rounded-xl border-2 text-left transition-all relative overflow-hidden",
                    formData.role === role.id 
                      ? "border-primary bg-primary/5 shadow-md" 
                      : "border-border bg-white hover:border-primary/30"
                  )}
                >
                  {formData.role === role.id && (
                    <div className="absolute top-2 right-2 text-primary">
                      <Check className="w-5 h-5" />
                    </div>
                  )}
                  <role.icon className={cn("w-8 h-8 mb-3", formData.role === role.id ? "text-primary" : "text-muted-foreground")} />
                  <div className="font-bold text-lg">{role.label}</div>
                  <div className="text-sm text-muted-foreground">{role.sub}</div>
                </button>
              ))}
            </div>
          </div>

          {/* Step 2: Details */}
          <div className="space-y-6 animate-in slide-in-from-bottom-4 duration-500">
             <h2 className="text-lg font-semibold flex items-center gap-2">
              <span className="w-6 h-6 rounded-full bg-primary/10 text-primary flex items-center justify-center text-xs">2</span>
              Your Details / विवरण
            </h2>

            <div className="grid gap-4 md:grid-cols-2">
              <div className="space-y-2">
                <label className="text-sm font-medium ml-1">Full Name / पूरा नाम</label>
                <input
                  type="text"
                  required
                  value={formData.name}
                  onChange={e => setFormData({...formData, name: e.target.value})}
                  className="input-field"
                  placeholder="e.g. Rahul Kumar"
                />
              </div>

              <div className="space-y-2">
                <label className="text-sm font-medium ml-1">City / शहर</label>
                <input
                  type="text"
                  required
                  value={formData.city}
                  onChange={e => setFormData({...formData, city: e.target.value})}
                  className="input-field"
                  placeholder="e.g. Jaipur"
                />
              </div>

              {/* Labourer Specific Fields */}
              {formData.role === "labourer" && (
                <>
                  <div className="space-y-2 md:col-span-2">
                    <label className="text-sm font-medium ml-1">Skill / कौशल</label>
                    <select
                      value={formData.skillCategory}
                      onChange={e => setFormData({...formData, skillCategory: e.target.value as any})}
                      className="input-field appearance-none bg-white"
                    >
                      {SKILL_CATEGORIES.map(skill => (
                        <option key={skill} value={skill}>{skill}</option>
                      ))}
                    </select>
                  </div>

                  <div className="space-y-2">
                    <label className="text-sm font-medium ml-1">Experience (Years) / अनुभव (वर्ष)</label>
                    <input
                      type="number"
                      value={formData.experienceYears}
                      onChange={e => setFormData({...formData, experienceYears: e.target.value})}
                      className="input-field"
                      placeholder="e.g. 5"
                    />
                  </div>

                  <div className="space-y-2">
                    <label className="text-sm font-medium ml-1">Daily Rate (₹) / दैनिक मजदूरी</label>
                    <input
                      type="number"
                      value={formData.dailyRate}
                      onChange={e => setFormData({...formData, dailyRate: e.target.value})}
                      className="input-field"
                      placeholder="e.g. 500"
                    />
                  </div>
                </>
              )}

              {/* Contractor Specific Fields */}
              {formData.role === "contractor" && (
                <div className="space-y-2 md:col-span-2">
                  <label className="text-sm font-medium ml-1">Organization Name / संगठन का नाम</label>
                  <input
                    type="text"
                    value={formData.organizationName}
                    onChange={e => setFormData({...formData, organizationName: e.target.value})}
                    className="input-field"
                    placeholder="e.g. RK Constructions"
                  />
                </div>
              )}
            </div>
          </div>

          <button
            disabled={isRegistering}
            className="w-full bg-primary text-white font-bold py-4 rounded-xl shadow-lg shadow-primary/25 hover:shadow-xl hover:shadow-primary/30 transition-all mt-8"
          >
            {isRegistering ? <Loader2 className="animate-spin w-5 h-5 mx-auto" /> : "Complete Registration / पूरा करें"}
          </button>
        </form>
      </div>
    </div>
  );
}
