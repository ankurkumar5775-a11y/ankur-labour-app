import { useEffect } from "react";
import { useLocation } from "wouter";
import { motion } from "framer-motion";
import { HardHat } from "lucide-react";

export default function Splash() {
  const [, setLocation] = useLocation();

  useEffect(() => {
    const timer = setTimeout(() => {
      setLocation("/auth");
    }, 2500);
    return () => clearTimeout(timer);
  }, [setLocation]);

  return (
    <div className="h-screen bg-primary flex flex-col items-center justify-center text-white p-6 relative overflow-hidden">
      <div className="absolute top-0 left-0 w-full h-full bg-[url('https://www.transparenttextures.com/patterns/cubes.png')] opacity-10"></div>
      
      <motion.div
        initial={{ scale: 0.8, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        transition={{ duration: 0.5, ease: "out" }}
        className="w-24 h-24 bg-white rounded-3xl flex items-center justify-center mb-6 shadow-2xl z-10"
      >
        <HardHat className="w-12 h-12 text-primary" strokeWidth={1.5} />
      </motion.div>

      <motion.div
        initial={{ y: 20, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ delay: 0.3, duration: 0.5 }}
        className="text-center z-10"
      >
        <h1 className="text-5xl font-bold font-display mb-2">ANKUR</h1>
        <p className="text-xl opacity-90 font-light">Labour & Contractor Connect</p>
        <p className="text-sm mt-2 opacity-80">मजदूर और ठेकेदार सेतु</p>
      </motion.div>

      <div className="absolute bottom-10 opacity-60 text-xs">
        Made for India 🇮🇳
      </div>
    </div>
  );
}
