import { useState } from "react";
import { useAuth } from "@/hooks/use-auth";
import { useLocation } from "wouter";
import { Loader2, ArrowRight, ShieldCheck, Phone } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

export default function AuthPage() {
  const [step, setStep] = useState<"phone" | "otp">("phone");
  const [mobile, setMobile] = useState("");
  const [otp, setOtp] = useState("");
  const { sendOtp, verifyOtp, isSendingOtp, isVerifyingOtp } = useAuth();
  const [, setLocation] = useLocation();

  const handleSendOtp = async (e: React.FormEvent) => {
    e.preventDefault();
    if (mobile.length < 10) return;
    try {
      await sendOtp({ mobile });
      setStep("otp");
    } catch (err) {
      // Error handled in hook
    }
  };

  const handleVerifyOtp = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const data = await verifyOtp({ mobile, code: otp });
      // If user exists and has a role, they are logged in.
      // If they are new (no role/name), we redirect to Register.
      // The API returns the user object. Check if fields are populated.
      if (!data.user || !data.user.name) {
        setLocation(`/register?mobile=${mobile}`);
      } else if (!data.user.role || data.user.role === 'admin') {
        // New users or incomplete profiles: select role
        setLocation("/role-select");
      } else {
        setLocation("/");
      }
    } catch (err) {
      // Error handled in hook
    }
  };

  return (
    <div className="min-h-screen bg-background flex flex-col justify-center px-6 relative overflow-hidden">
      {/* Decorative background circle */}
      <div className="absolute -top-20 -right-20 w-64 h-64 bg-primary/10 rounded-full blur-3xl" />
      <div className="absolute -bottom-20 -left-20 w-64 h-64 bg-accent/10 rounded-full blur-3xl" />

      <div className="max-w-md mx-auto w-full relative z-10">
        <div className="text-center mb-10">
          <div className="w-16 h-16 bg-gradient-to-br from-primary to-orange-600 rounded-2xl mx-auto flex items-center justify-center shadow-lg shadow-primary/30 mb-6">
            <ShieldCheck className="w-8 h-8 text-white" />
          </div>
          <h1 className="text-4xl font-bold font-display text-primary mb-2">ANKUR</h1>
          <p className="text-muted-foreground text-lg">Labour & Contractor Connect</p>
          <p className="text-sm text-muted-foreground mt-1">मजदूर और ठेकेदार सेतु</p>
        </div>

        <div className="bg-card border border-border/50 shadow-xl rounded-3xl p-8 backdrop-blur-sm bg-white/80">
          <AnimatePresence mode="wait">
            {step === "phone" ? (
              <motion.form
                key="phone-form"
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: 20 }}
                onSubmit={handleSendOtp}
                className="space-y-6"
              >
                <div className="space-y-2">
                  <label className="text-sm font-medium text-foreground ml-1">Mobile Number / मोबाइल नंबर</label>
                  <div className="relative">
                    <Phone className="absolute left-4 top-1/2 -translate-y-1/2 text-muted-foreground w-5 h-5" />
                    <input
                      type="tel"
                      value={mobile}
                      onChange={(e) => setMobile(e.target.value.replace(/\D/g, ''))}
                      className="w-full pl-12 pr-4 py-4 bg-secondary/30 border-2 border-transparent focus:bg-white focus:border-primary rounded-xl text-lg font-medium outline-none transition-all"
                      placeholder="9876543210"
                      maxLength={10}
                      required
                    />
                  </div>
                </div>

                <button
                  disabled={isSendingOtp || mobile.length < 10}
                  className="w-full bg-primary text-white font-bold py-4 rounded-xl flex items-center justify-center gap-2 shadow-lg shadow-primary/25 hover:shadow-xl hover:shadow-primary/30 disabled:opacity-50 disabled:shadow-none transition-all"
                >
                  {isSendingOtp ? <Loader2 className="animate-spin w-5 h-5" /> : (
                    <>
                      Send OTP / ओटीपी भेजें <ArrowRight className="w-5 h-5" />
                    </>
                  )}
                </button>
              </motion.form>
            ) : (
              <motion.form
                key="otp-form"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                onSubmit={handleVerifyOtp}
                className="space-y-6"
              >
                <div className="text-center mb-4">
                  <p className="text-sm text-muted-foreground">OTP sent to +91 {mobile}</p>
                  <button 
                    type="button" 
                    onClick={() => setStep("phone")}
                    className="text-primary text-xs font-semibold mt-1 hover:underline"
                  >
                    Change Number / बदलें
                  </button>
                </div>

                <div className="space-y-2">
                  <label className="text-sm font-medium text-foreground ml-1">Enter OTP / ओटीपी डालें</label>
                  <input
                    type="text"
                    value={otp}
                    onChange={(e) => setOtp(e.target.value)}
                    className="w-full px-4 py-4 text-center tracking-[1em] bg-secondary/30 border-2 border-transparent focus:bg-white focus:border-primary rounded-xl text-2xl font-bold outline-none transition-all"
                    placeholder="••••"
                    maxLength={4}
                    required
                  />
                  <p className="text-xs text-center text-muted-foreground mt-2">Use Mock OTP: 1234</p>
                </div>

                <button
                  disabled={isVerifyingOtp || otp.length < 4}
                  className="w-full bg-primary text-white font-bold py-4 rounded-xl flex items-center justify-center gap-2 shadow-lg shadow-primary/25 hover:shadow-xl hover:shadow-primary/30 disabled:opacity-50 disabled:shadow-none transition-all"
                >
                  {isVerifyingOtp ? <Loader2 className="animate-spin w-5 h-5" /> : "Login / लॉग इन"}
                </button>
              </motion.form>
            )}
          </AnimatePresence>
        </div>
      </div>
    </div>
  );
}
