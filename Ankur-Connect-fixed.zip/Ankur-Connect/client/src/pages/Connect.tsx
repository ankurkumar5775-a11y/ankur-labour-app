import { Link } from "wouter";
import { Users, Phone } from "lucide-react";

// Mock saved contacts for now, since we don't have a backend for saved workers yet.
// In a real app, this would be useSavedWorkers()

const SAVED_WORKERS = [
  { id: 1, name: "Ramesh Kumar", skill: "Plumber", phone: "9876543210", lastCalled: "Yesterday" },
  { id: 2, name: "Suresh Singh", skill: "Electrician", phone: "9876543211", lastCalled: "2 days ago" },
];

export default function Connect() {
  return (
    <div className="min-h-screen bg-background pb-24">
      <header className="bg-white border-b border-border p-4 sticky top-0 z-10">
        <h1 className="text-2xl font-bold font-display text-primary">My Connections</h1>
        <p className="text-sm text-muted-foreground">संपर्क सूची</p>
      </header>

      <main className="p-4 max-w-2xl mx-auto">
        {SAVED_WORKERS.length > 0 ? (
          <div className="space-y-3">
             {SAVED_WORKERS.map(worker => (
               <div key={worker.id} className="bg-white p-4 rounded-xl border border-border shadow-sm flex items-center justify-between">
                 <div className="flex items-center gap-3">
                   <div className="w-10 h-10 rounded-full bg-secondary flex items-center justify-center font-bold text-muted-foreground">
                     {worker.name.charAt(0)}
                   </div>
                   <div>
                     <h3 className="font-bold text-foreground">{worker.name}</h3>
                     <p className="text-xs text-muted-foreground">{worker.skill} • {worker.lastCalled}</p>
                   </div>
                 </div>
                 
                 <a href={`tel:${worker.phone}`} className="w-10 h-10 rounded-full bg-green-100 flex items-center justify-center text-green-600 hover:bg-green-200 transition-colors">
                   <Phone className="w-5 h-5" />
                 </a>
               </div>
             ))}
          </div>
        ) : (
          <div className="text-center py-20">
            <div className="w-20 h-20 bg-secondary rounded-full flex items-center justify-center mx-auto mb-4 text-muted-foreground">
              <Users className="w-10 h-10" />
            </div>
            <h3 className="text-lg font-bold">No Connections Yet</h3>
            <p className="text-muted-foreground mb-6">Call workers to add them to your history.</p>
            <Link href="/" className="btn-primary inline-block">
              Find Workers
            </Link>
          </div>
        )}
      </main>
    </div>
  );
}
