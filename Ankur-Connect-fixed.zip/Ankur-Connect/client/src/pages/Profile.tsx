import { useAuth } from "@/hooks/use-auth";
import { useUpdateLabourerProfile } from "@/hooks/use-labourers";
import { LogOut, User, Phone, MapPin, Briefcase, IndianRupee, Clock, Power, PenSquare } from "lucide-react";
import { useState } from "react";
import { Loader2 } from "lucide-react";

export default function Profile() {
  const { user, logout } = useAuth();
  const updateProfile = useUpdateLabourerProfile();
  const [isEditing, setIsEditing] = useState(false);
  const [bio, setBio] = useState(user?.labourerProfile?.bio || "");
  const [rate, setRate] = useState(user?.labourerProfile?.dailyRate?.toString() || "");

  if (!user) return null;

  const isLabourer = user.role === "labourer";
  const profile = user.labourerProfile;

  const handleToggleAvailability = () => {
    if (!profile) return;
    updateProfile.mutate({
      id: profile.id,
      data: { isAvailable: !profile.isAvailable }
    });
  };

  const handleSave = async () => {
    if (!profile) return;
    await updateProfile.mutateAsync({
        id: profile.id,
        data: { bio, dailyRate: Number(rate) }
    });
    setIsEditing(false);
  };

  return (
    <div className="min-h-screen bg-background pb-24">
      <div className="bg-primary h-48 relative">
        <div className="absolute -bottom-16 left-1/2 -translate-x-1/2">
            <div className="w-32 h-32 rounded-2xl bg-white p-1 shadow-xl">
                 <div className="w-full h-full bg-secondary rounded-xl flex items-center justify-center text-4xl font-bold text-muted-foreground">
                    {user.name.charAt(0)}
                 </div>
            </div>
        </div>
      </div>

      <div className="mt-20 px-4 text-center max-w-md mx-auto">
        <h1 className="text-2xl font-bold text-foreground">{user.name}</h1>
        <div className="flex justify-center gap-2 mt-1">
          <span className="inline-block bg-primary/10 text-primary px-3 py-1 rounded-full text-xs font-bold capitalize">
            {user.role}
          </span>
          {isLabourer && profile?.isVerified && (
            <span className="inline-block bg-blue-50 text-blue-700 px-3 py-1 rounded-full text-xs font-bold flex items-center gap-1">
              <span>✓</span> Verified
            </span>
          )}
        </div>
        
        {isLabourer && profile && (
          <div className="mt-6 flex justify-center">
             <button
               onClick={handleToggleAvailability}
               className={`flex items-center gap-2 px-6 py-2 rounded-full font-bold transition-all ${
                 profile.isAvailable 
                   ? 'bg-green-100 text-green-700 hover:bg-green-200' 
                   : 'bg-red-100 text-red-700 hover:bg-red-200'
               }`}
             >
               <Power className="w-4 h-4" />
               {profile.isAvailable ? "Available for Work" : "Not Available"}
             </button>
          </div>
        )}
      </div>

      <div className="mt-8 px-4 max-w-md mx-auto space-y-4">
        <div className="bg-white rounded-2xl shadow-sm border border-border p-5">
            <h3 className="font-bold text-lg mb-4 flex items-center gap-2">
                Details
                {isLabourer && !isEditing && (
                    <button onClick={() => setIsEditing(true)} className="ml-auto text-primary p-2 hover:bg-primary/5 rounded-lg">
                        <PenSquare className="w-5 h-5" />
                    </button>
                )}
            </h3>
            
            <div className="space-y-4">
                <div className="flex items-center gap-3 text-sm">
                    <Phone className="w-5 h-5 text-muted-foreground" />
                    <span className="font-medium">+91 {user.mobile}</span>
                </div>
                <div className="flex items-center gap-3 text-sm">
                    <MapPin className="w-5 h-5 text-muted-foreground" />
                    <span className="font-medium">{user.city}</span>
                </div>

                {isLabourer && profile && (
                    <>
                        <div className="flex items-center gap-3 text-sm">
                            <Briefcase className="w-5 h-5 text-muted-foreground" />
                            <div>
                              <p className="font-medium">{profile.skillCategory}</p>
                              <p className="text-xs text-muted-foreground">{profile.experienceYears} years experience</p>
                            </div>
                        </div>

                        <div className="flex items-center gap-3 text-sm">
                            <IndianRupee className="w-5 h-5 text-muted-foreground" />
                            <div>
                              <p className="font-medium">₹{profile.dailyRate} per day</p>
                              <p className="text-xs text-muted-foreground">Daily rate</p>
                            </div>
                        </div>

                        {profile.bio && (
                          <div className="flex items-start gap-3 text-sm pt-2 border-t border-border">
                            <div>
                              <p className="font-medium text-foreground">{profile.bio}</p>
                              <p className="text-xs text-muted-foreground mt-1">About you</p>
                            </div>
                          </div>
                        )}
                        
                        {isEditing ? (
                            <div className="space-y-4 pt-4 border-t">
                                <div className="space-y-1">
                                    <label className="text-xs font-semibold text-muted-foreground">Daily Rate (₹)</label>
                                    <input 
                                        type="number" 
                                        value={rate} 
                                        onChange={e => setRate(e.target.value)} 
                                        className="input-field py-2 text-sm"
                                    />
                                </div>
                                <div className="space-y-1">
                                    <label className="text-xs font-semibold text-muted-foreground">Bio / About</label>
                                    <textarea 
                                        value={bio} 
                                        onChange={e => setBio(e.target.value)} 
                                        className="input-field py-2 text-sm min-h-[80px]"
                                    />
                                </div>
                                <div className="flex gap-2">
                                    <button onClick={handleSave} disabled={updateProfile.isPending} className="flex-1 bg-primary text-white py-2 rounded-lg font-bold text-sm">
                                        {updateProfile.isPending ? <Loader2 className="animate-spin w-4 h-4 mx-auto" /> : "Save Changes"}
                                    </button>
                                    <button onClick={() => setIsEditing(false)} className="px-4 bg-secondary text-secondary-foreground py-2 rounded-lg font-bold text-sm">
                                        Cancel
                                    </button>
                                </div>
                            </div>
                        ) : (
                            <>
                                <div className="flex items-center gap-3 text-sm">
                                    <IndianRupee className="w-5 h-5 text-muted-foreground" />
                                    <span className="font-medium">₹{profile.dailyRate} / Day</span>
                                </div>
                                {profile.bio && (
                                    <p className="text-sm text-muted-foreground mt-2 bg-secondary/30 p-3 rounded-lg">
                                        "{profile.bio}"
                                    </p>
                                )}
                            </>
                        )}
                    </>
                )}
            </div>
        </div>

        <button 
          onClick={() => logout()}
          className="w-full flex items-center justify-center gap-2 p-4 text-red-600 font-bold hover:bg-red-50 rounded-xl transition-colors"
        >
          <LogOut className="w-5 h-5" />
          Logout / लॉग आउट
        </button>
      </div>
    </div>
  );
}
