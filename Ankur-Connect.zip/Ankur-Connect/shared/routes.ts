import { z } from 'zod';
import { insertUserSchema, insertLabourerProfileSchema, insertContractorProfileSchema, users, labourerProfiles, contractorProfiles } from './schema';

export const errorSchemas = {
  validation: z.object({
    message: z.string(),
    field: z.string().optional(),
  }),
  notFound: z.object({
    message: z.string(),
  }),
  internal: z.object({
    message: z.string(),
  }),
  unauthorized: z.object({
    message: z.string(),
  }),
};

export const api = {
  auth: {
    sendOtp: {
      method: 'POST' as const,
      path: '/api/auth/send-otp',
      input: z.object({ mobile: z.string() }),
      responses: {
        200: z.object({ message: z.string() }),
        400: errorSchemas.validation,
      },
    },
    verifyOtp: {
      method: 'POST' as const,
      path: '/api/auth/verify-otp',
      input: z.object({ mobile: z.string(), code: z.string() }),
      responses: {
        200: z.object({ token: z.string(), user: z.custom<any>() }), // UserWithProfile
        400: errorSchemas.validation,
        401: errorSchemas.unauthorized,
      },
    },
    register: {
      method: 'POST' as const,
      path: '/api/auth/register',
      input: z.object({
        mobile: z.string(),
        name: z.string(),
        city: z.string(),
        role: z.enum(["customer", "labourer", "contractor", "admin"]),
        // Labourer specific
        skillCategory: z.enum(["Mason", "Electrician", "Plumber", "Painter", "Carpenter", "Helper", "Daily Wage Worker", "Other"]).optional(),
        experienceYears: z.coerce.number().optional(),
        dailyRate: z.coerce.number().optional(),
        // Contractor specific
        organizationName: z.string().optional(),
      }),
      responses: {
        201: z.object({ token: z.string(), user: z.custom<any>() }),
        400: errorSchemas.validation,
      },
    },
    me: {
      method: 'GET' as const,
      path: '/api/auth/me',
      responses: {
        200: z.custom<any>(), // UserWithProfile
        401: errorSchemas.unauthorized,
      },
    },
  },
  labourers: {
    list: {
      method: 'GET' as const,
      path: '/api/labourers',
      input: z.object({
        city: z.string().optional(),
        skill: z.string().optional(),
        search: z.string().optional(),
      }).optional(),
      responses: {
        200: z.array(z.custom<any>()), // Array of User & { labourerProfile: ... }
      },
    },
    get: {
      method: 'GET' as const,
      path: '/api/labourers/:id',
      responses: {
        200: z.custom<any>(),
        404: errorSchemas.notFound,
      },
    },
    update: {
        method: 'PUT' as const,
        path: '/api/labourers/:id',
        input: insertLabourerProfileSchema.partial(),
        responses: {
            200: z.custom<any>(),
            404: errorSchemas.notFound,
        }
    }
  },
  contractors: {
      list: {
          method: 'GET' as const,
          path: '/api/contractors',
          responses: {
              200: z.array(z.custom<any>())
          }
      },
      addLabourer: {
          method: 'POST' as const,
          path: '/api/contractors/:id/labourers',
          input: z.object({ labourerId: z.coerce.number() }),
          responses: {
              200: z.object({ message: z.string() }),
              404: errorSchemas.notFound,
          }
      },
      removeLabourer: {
          method: 'DELETE' as const,
          path: '/api/contractors/:id/labourers/:labourerId',
          responses: {
              200: z.object({ message: z.string() }),
              404: errorSchemas.notFound,
          }
      }
  },
  admin: {
      listUsers: {
          method: 'GET' as const,
          path: '/api/admin/users',
          input: z.object({
              role: z.string().optional(),
              blocked: z.string().optional(),
          }).optional(),
          responses: {
              200: z.array(z.custom<any>()),
              401: errorSchemas.unauthorized,
          }
      },
      verifyUser: {
          method: 'PATCH' as const,
          path: '/api/admin/users/:id/verify',
          input: z.object({ verified: z.boolean() }),
          responses: {
              200: z.object({ message: z.string() }),
              404: errorSchemas.notFound,
          }
      },
      blockUser: {
          method: 'PATCH' as const,
          path: '/api/admin/users/:id/block',
          input: z.object({ blocked: z.boolean() }),
          responses: {
              200: z.object({ message: z.string() }),
              404: errorSchemas.notFound,
          }
      }
  }
};

export function buildUrl(path: string, params?: Record<string, string | number>): string {
  let url = path;
  if (params) {
    Object.entries(params).forEach(([key, value]) => {
      if (url.includes(`:${key}`)) {
        url = url.replace(`:${key}`, String(value));
      }
    });
  }
  return url;
}
