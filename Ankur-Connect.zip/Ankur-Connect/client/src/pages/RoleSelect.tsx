import { useLocation } from 'wouter';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { useAuth } from '@/hooks/use-auth';
import { useLanguage } from '@/contexts/LanguageContext';
import { Briefcase, Wrench, Users } from 'lucide-react';

export default function RoleSelect() {
  const [, setLocation] = useLocation();
  const { selectRole } = useAuth();
  const { t } = useLanguage();

  const handleRoleSelect = (role: 'customer' | 'labourer' | 'contractor') => {
    selectRole(role);
    setLocation('/');
  };

  return (
    <div className="min-h-screen bg-background flex items-center justify-center p-4">
      <div className="w-full max-w-md">
        <h1 className="text-3xl font-bold text-center mb-8 text-primary">{t('selectRole')}</h1>
        
        <div className="space-y-4">
          {/* Customer */}
          <Card 
            className="p-6 cursor-pointer hover-elevate"
            onClick={() => handleRoleSelect('customer')}
            data-testid="button-select-customer"
          >
            <div className="flex items-center gap-4">
              <Users className="w-8 h-8 text-primary" />
              <div>
                <h2 className="font-bold text-lg">{t('customer')}</h2>
                <p className="text-sm text-muted-foreground">Find skilled workers</p>
              </div>
            </div>
          </Card>

          {/* Labourer */}
          <Card 
            className="p-6 cursor-pointer hover-elevate"
            onClick={() => handleRoleSelect('labourer')}
            data-testid="button-select-labourer"
          >
            <div className="flex items-center gap-4">
              <Wrench className="w-8 h-8 text-primary" />
              <div>
                <h2 className="font-bold text-lg">{t('labourer')}</h2>
                <p className="text-sm text-muted-foreground">Offer your skills</p>
              </div>
            </div>
          </Card>

          {/* Contractor */}
          <Card 
            className="p-6 cursor-pointer hover-elevate"
            onClick={() => handleRoleSelect('contractor')}
            data-testid="button-select-contractor"
          >
            <div className="flex items-center gap-4">
              <Briefcase className="w-8 h-8 text-primary" />
              <div>
                <h2 className="font-bold text-lg">{t('contractor')}</h2>
                <p className="text-sm text-muted-foreground">Manage teams</p>
              </div>
            </div>
          </Card>
        </div>
      </div>
    </div>
  );
}
