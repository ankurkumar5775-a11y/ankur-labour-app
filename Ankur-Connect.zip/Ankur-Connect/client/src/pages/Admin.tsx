import { useQuery, useMutation } from '@tanstack/react-query';
import { useAuth } from '@/hooks/use-auth';
import { useLocation } from 'wouter';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { useLanguage } from '@/contexts/LanguageContext';
import { Shield, CheckCircle, XCircle, Loader2 } from 'lucide-react';
import { api } from '@shared/routes';
import { queryClient } from '@/lib/queryClient';

export default function Admin() {
  const { user } = useAuth();
  const [, setLocation] = useLocation();
  const { t } = useLanguage();

  // Only admins can access
  if (user?.role !== 'admin') {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <p className="text-destructive font-bold">Access Denied</p>
      </div>
    );
  }

  const { data: users = [], isLoading } = useQuery({
    queryKey: ['/api/admin/users'],
    queryFn: async () => {
      const res = await fetch('/api/admin/users');
      return res.json();
    },
  });

  const verifyMutation = useMutation({
    mutationFn: async ({ id, verified }: { id: number; verified: boolean }) => {
      const res = await fetch(`/api/admin/users/${id}/verify`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ verified }),
      });
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/admin/users'] });
    },
  });

  const blockMutation = useMutation({
    mutationFn: async ({ id, blocked }: { id: number; blocked: boolean }) => {
      const res = await fetch(`/api/admin/users/${id}/block`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ blocked }),
      });
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/admin/users'] });
    },
  });

  if (isLoading) {
    return <div className="flex justify-center items-center min-h-screen"><Loader2 className="w-8 h-8 animate-spin" /></div>;
  }

  return (
    <div className="min-h-screen bg-background p-4 pb-20">
      <div className="max-w-2xl mx-auto">
        <div className="flex items-center gap-2 mb-6">
          <Shield className="w-6 h-6 text-primary" />
          <h1 className="text-2xl font-bold">{t('admin')} Panel</h1>
        </div>

        <div className="space-y-3">
          {users.map((u: any) => (
            <Card key={u.id} className="p-4">
              <div className="flex items-start justify-between gap-4">
                <div className="flex-1">
                  <h3 className="font-bold">{u.name}</h3>
                  <p className="text-sm text-muted-foreground">{u.mobile} • {u.city}</p>
                  <div className="flex gap-2 mt-2">
                    <Badge variant="outline">{u.role}</Badge>
                    {u.isBlocked && <Badge variant="destructive">Blocked</Badge>}
                    {u.labourerProfile?.isVerified && <Badge variant="secondary">Verified</Badge>}
                  </div>
                </div>
                <div className="flex gap-2 flex-col">
                  {u.role === 'labourer' && (
                    <Button
                      size="sm"
                      variant={u.labourerProfile?.isVerified ? 'outline' : 'default'}
                      onClick={() => verifyMutation.mutate({ id: u.id, verified: !u.labourerProfile?.isVerified })}
                      data-testid={`button-verify-${u.id}`}
                    >
                      {u.labourerProfile?.isVerified ? (
                        <><CheckCircle className="w-3 h-3 mr-1" /> Verified</>
                      ) : (
                        'Verify'
                      )}
                    </Button>
                  )}
                  <Button
                    size="sm"
                    variant={u.isBlocked ? 'secondary' : 'destructive'}
                    onClick={() => blockMutation.mutate({ id: u.id, blocked: !u.isBlocked })}
                    data-testid={`button-block-${u.id}`}
                  >
                    {u.isBlocked ? (
                      <><XCircle className="w-3 h-3 mr-1" /> Blocked</>
                    ) : (
                      'Block'
                    )}
                  </Button>
                </div>
              </div>
            </Card>
          ))}
        </div>
      </div>
    </div>
  );
}
