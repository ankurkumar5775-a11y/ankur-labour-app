import { Link, useLocation } from "wouter";
import { Home, User, Users } from "lucide-react";
import { useAuth } from "@/hooks/use-auth";

export function BottomNav() {
  const [location] = useLocation();
  const { user } = useAuth();
  
  // Don't show on auth pages
  if (location === "/auth" || location === "/register" || location === "/splash") return null;

  return (
    <div className="fixed bottom-0 left-0 right-0 bg-white border-t border-border shadow-[0_-5px_10px_rgba(0,0,0,0.05)] pb-safe-area z-50">
      <div className="flex justify-around items-center h-16 max-w-md mx-auto">
        <Link href="/" className={`flex flex-col items-center justify-center w-full h-full space-y-1 ${location === '/' ? 'text-primary' : 'text-muted-foreground'}`}>
          <Home className="w-6 h-6" />
          <span className="text-xs font-medium">Home</span>
        </Link>
        
        {/* Only show 'Connect' (saved workers) if user is a customer or contractor */}
        {(user?.role === 'customer' || user?.role === 'contractor') && (
          <Link href="/connect" className={`flex flex-col items-center justify-center w-full h-full space-y-1 ${location === '/connect' ? 'text-primary' : 'text-muted-foreground'}`}>
            <Users className="w-6 h-6" />
            <span className="text-xs font-medium">Connect</span>
          </Link>
        )}

        <Link href="/profile" className={`flex flex-col items-center justify-center w-full h-full space-y-1 ${location === '/profile' ? 'text-primary' : 'text-muted-foreground'}`}>
          <User className="w-6 h-6" />
          <span className="text-xs font-medium">Profile</span>
        </Link>
      </div>
    </div>
  );
}
