import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { api, buildUrl, type InsertLabourerProfile } from "@shared/routes";
import { useToast } from "@/hooks/use-toast";

export function useLabourers(filters?: { city?: string; skill?: string; search?: string }) {
  // Construct query string manually since URLSearchParams handles undefined oddly
  const queryParams = new URLSearchParams();
  if (filters?.city) queryParams.append("city", filters.city);
  if (filters?.skill) queryParams.append("skill", filters.skill);
  if (filters?.search) queryParams.append("search", filters.search);
  
  const queryString = queryParams.toString();
  const path = `${api.labourers.list.path}${queryString ? `?${queryString}` : ""}`;

  return useQuery({
    queryKey: [api.labourers.list.path, filters],
    queryFn: async () => {
      const res = await fetch(path, { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch labourers");
      return api.labourers.list.responses[200].parse(await res.json());
    },
  });
}

export function useLabourer(id: number) {
  return useQuery({
    queryKey: [api.labourers.get.path, id],
    queryFn: async () => {
      const url = buildUrl(api.labourers.get.path, { id });
      const res = await fetch(url, { credentials: "include" });
      if (res.status === 404) return null;
      if (!res.ok) throw new Error("Failed to fetch labourer");
      return api.labourers.get.responses[200].parse(await res.json());
    },
    enabled: !!id,
  });
}

export function useUpdateLabourerProfile() {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  return useMutation({
    mutationFn: async ({ id, data }: { id: number; data: Partial<InsertLabourerProfile> }) => {
      const url = buildUrl(api.labourers.update.path, { id });
      const res = await fetch(url, {
        method: api.labourers.update.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
        credentials: "include",
      });

      if (!res.ok) throw new Error("Failed to update profile");
      return api.labourers.update.responses[200].parse(await res.json());
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: [api.labourers.get.path, data.id] });
      queryClient.invalidateQueries({ queryKey: [api.auth.me.path] });
      toast({
        title: "Updated / अद्यतन",
        description: "Profile updated successfully",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to update profile",
        variant: "destructive",
      });
    }
  });
}
