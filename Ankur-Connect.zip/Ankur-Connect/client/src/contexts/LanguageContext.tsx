import React, { createContext, useContext, useState, useEffect } from 'react';

type Language = 'en' | 'hi';

interface LanguageContextType {
  language: Language;
  toggleLanguage: () => void;
  t: (key: string) => string;
}

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

const translations: Record<Language, Record<string, string>> = {
  en: {
    'search': 'Search',
    'available': 'Available',
    'busy': 'Busy',
    'call': 'Call Now',
    'whatsapp': 'WhatsApp',
    'edit': 'Edit',
    'save': 'Save',
    'cancel': 'Cancel',
    'home': 'Home',
    'profile': 'Profile',
    'connect': 'Connect',
    'skill': 'Skill',
    'experience': 'Experience',
    'rate': 'Daily Rate',
    'city': 'City',
    'verified': 'Verified',
    'admin': 'Admin',
    'approve': 'Approve',
    'block': 'Block',
    'unblock': 'Unblock',
    'selectRole': 'Select Your Role',
    'customer': 'Customer',
    'labourer': 'Labourer',
    'contractor': 'Contractor',
  },
  hi: {
    'search': 'खोजें',
    'available': 'उपलब्ध',
    'busy': 'व्यस्त',
    'call': 'अभी कॉल करें',
    'whatsapp': 'व्हाट्सएप',
    'edit': 'संपादित करें',
    'save': 'सहेजें',
    'cancel': 'रद्द करें',
    'home': 'होम',
    'profile': 'प्रोफाइल',
    'connect': 'कनेक्ट',
    'skill': 'कौशल',
    'experience': 'अनुभव',
    'rate': 'दैनिक दर',
    'city': 'शहर',
    'verified': 'सत्यापित',
    'admin': 'प्रशासक',
    'approve': 'स्वीकृति',
    'block': 'ब्लॉक',
    'unblock': 'अनब्लॉक',
    'selectRole': 'अपनी भूमिका चुनें',
    'customer': 'ग्राहक',
    'labourer': 'मजदूर',
    'contractor': 'ठेकेदार',
  }
};

export const LanguageProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [language, setLanguage] = useState<Language>(() => {
    const saved = localStorage.getItem('language');
    return (saved as Language) || 'en';
  });

  useEffect(() => {
    localStorage.setItem('language', language);
  }, [language]);

  const toggleLanguage = () => {
    setLanguage(prev => prev === 'en' ? 'hi' : 'en');
  };

  const t = (key: string) => {
    return translations[language][key as keyof typeof translations['en']] || key;
  };

  return (
    <LanguageContext.Provider value={{ language, toggleLanguage, t }}>
      {children}
    </LanguageContext.Provider>
  );
};

export const useLanguage = () => {
  const context = useContext(LanguageContext);
  if (!context) {
    throw new Error('useLanguage must be used within LanguageProvider');
  }
  return context;
};
